# PayCare Demo Website

A responsive, static sign-in-style prototype inspired by common payment-service layouts.

## Safety notes
- This is a demo UI only.
- It uses a demo access code, not a password or payment PIN.
- Form submissions are handled in the browser only; no information is sent or saved.
- Do not use this to impersonate another service or collect real account credentials.

## Run it
Open `index.html` in a browser, or upload the project to a GitHub repository and enable GitHub Pages.
